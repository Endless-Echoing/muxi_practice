import { useState,useEffect,useCallback } from'react';

import './App.css';

export default function useCounter() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    console.log(`Count has changed to: ${count}`);
  },[ count ]);

  const increment = useCallback(() => {
    setCount(prevCount => prevCount + 1);
  }, []);

  const decrement = useCallback(() =>{
    setCount(prevCount => prevCount - 1);
  },[]);

  const reset = useCallback(() => {
    setCount(0);
  }, []);

  return (
    <div style={{textAlign: 'center'}}>
      <p>Counter: {count}</p>
      <div className='button-group'>
      <button className='Increment' onClick={increment}>Increment</button>
      <button className='Decrement' onClick={decrement}>Decrement</button>
      </div>
      <button className='Reset' onClick={reset}>Reset</button>
    </div>
  );
}



