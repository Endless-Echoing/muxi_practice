import {Profile} from './Profile';

export default function Gallery() {
    return(
        <section>
            <h1>了不起的图片们</h1>
            <Profile 
            src="https://img.ixintu.com/download/jpg/201911/e25b904bc42a74d7d77aed81e66d772c.jpg!con"
            alt="风景"/>
            <Profile 
            src="https://pic.52112.com/2019/06/06/JPS-190606_155/24poJOgl7m_small.jpg"
            alt="小猫"/> 
            <Profile 
            src="https://img95.699pic.com/photo/50172/5228.jpg_wh860.jpg"
            alt="城市"/>
        </section>
    );
}