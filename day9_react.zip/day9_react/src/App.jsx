import Gallery from './Gallery';

export default function App() {
    return (
        <div>
            <Gallery />
        </div>
    );
}