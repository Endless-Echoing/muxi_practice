import React, { useState, useReducer, useContext, useEffect, useMemo, useRef } from 'react';

const TodoContext = React.createContext();

const initialState = {
  todos: []
};

function todoReducer(state, action) {
  switch (action.type) {
    case 'ADD_TODO':
      return {
        todos: [...state.todos, {
          id: Date.now(),
          text: action.payload,
          completed: false
        }]
      };
    case 'DELETE_TODO':
      return {
        todos: state.todos.filter(todo => todo.id !== action.payload)
      };
    case 'TOGGLE_TODO':
      return {
        todos: state.todos.map(todo =>
          todo.id === action.payload ? { ...todo, completed: !todo.completed } : todo
        )
      };
    default:
      return state;
  }
}

function TodoProvider({ children }) {
  const [state, dispatch] = useReducer(todoReducer, initialState);

  return (
    <TodoContext.Provider value={{ state, dispatch }}>
      {children}
    </TodoContext.Provider>
  );
}

function TodoForm() {
  const { dispatch } = useContext(TodoContext);
  const [inputValue, setInputValue] = useState(''); // 受控组件方式
  const inputRef = useRef(null); // 非受控组件方式

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    
    dispatch({ type: 'ADD_TODO', payload: inputValue });
    setInputValue('');
    inputRef.current.value = ''; // 非受控组件清空方式
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={inputValue} // 受控组件
        onChange={(e) => setInputValue(e.target.value)}
        ref={inputRef} // 非受控组件
        placeholder="输入任务内容"
      />
      <button type="submit">添加</button>
    </form>
  );
}

function TodoItem({ todo }) {
  const { dispatch } = useContext(TodoContext);

  return (
    <li style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={() => dispatch({ type: 'TOGGLE_TODO', payload: todo.id })}
      />
      {todo.text}
      <button onClick={() => dispatch({ type: 'DELETE_TODO', payload: todo.id })}>
        删除
      </button>
    </li>
  );
}

function TodoList() {
  const { state } = useContext(TodoContext);
  
  // 使用useMemo优化列表渲染
  const memoizedTodoList = useMemo(() => {
    return state.todos.map(todo => (
      <TodoItem key={todo.id} todo={todo} />
    ));
  }, [state.todos]);

  useEffect(() => {
    console.log('Todo List已加载');
  }, []);

  return (
    <ul>
      {memoizedTodoList}
    </ul>
  );
}

function App() {
  return (
    <TodoProvider>
      <div style={{ maxWidth: '400px', margin: '0 auto' }}>
        <h1>简易TodoList</h1>
        <TodoForm />
        <TodoList />
      </div>
    </TodoProvider>
  );
}

export default App;