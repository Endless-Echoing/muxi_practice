import { createContext,useContext } from 'react';
import { useState,useEffect,useCallback } from'react';

import './App.css';

const ThemeContext = createContext();

function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}


// 主题卡片组件
function ThemeCard() {
  const { theme } = useTheme();
  return (
    <div className={`theme-card ${theme}`}>
      <h3>当前主题: {theme === 'light' ? '明亮模式' : '暗黑模式'}</h3>
      <p>主题值: {theme}</p>
    </div>
  );
}

// 主题切换按钮
function ThemeButton() {
  const { toggleTheme, theme } = useTheme();
  return (
    <button className={`theme-button ${theme}`} onClick={toggleTheme}>
      切换主题
    </button>
  );
}

export default function App() {
  const [theme, setTheme] = useState('light');

  const toggleTheme = useCallback(() => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  useEffect(() => {
    document.body.className = theme;
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <div className={`app ${theme}`}>
        <h1>主题切换演示</h1>
        <ThemeCard />
        <ThemeButton />
        <useCounter/>
      </div>
    </ThemeContext.Provider>
  );
}
